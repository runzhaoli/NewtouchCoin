
var express = require('express');
var fs = require('fs');
var solc = require('solc');


//部署智能合约
// let source = fs.readdirSync("./contracts/BasicToken.sol", 'utf8');
// console.log('compiling contract...');
// let compiledContract = solc.compile(source);
// console.log('done');
// for (let contractName in compiledContract.contracts) {
//     var bytecode = compiledContract.contracts[contractName].bytecode;
//     var abi = JSON.parse(compiledContract.contracts[contractName].interface);
// }
//
// console.log(JSON.stringify(abi, undefined, 2));
//
// var address = '0x1a317a430d3231c755ac7b7252146b9aceedfe0d';


var router = express.Router();
//引用web3模块
var Web3 = require('web3');
//创建web3实例
var web3 = new Web3();
var web3Admin = require('web3admin');
web3Admin.extend(web3);
//创建http连接到区块链


console.log(web3.setProvider(new web3.providers.HttpProvider("http://10.6.6.5:8080")));



//判断当前连接的节点是否存在
router.get('/isConnect',function (req, res, next) {
    if(web3.isConnected()){
        console.log("该节点已存在");
        message.respCode = '00';
        message.errMessage = '该节点已存在';
        message.data = {connected: true};
    }else {
        console.log("该节点不存在");
        message.respCode = '01';
        message.errMessage = '该节点不存在';
        message.data = {connected: false};
    }
    res.json(message);
})


//获得区块链主账户
/* GET home page. */

var message = {
    "respCode":"",
    "errMessage":"",
    "data":""
}
var state;


// 连接节点
var connect = function (ip) {

    console.log("正在连接-------");

    return web3.setProvider(new web3.providers.HttpProvider(ip));

}

//检测当前有没有连接节点
router.post('/getProvide',function (req, res, next) {

    var provider = web3.currentProvider;
    if(provider){
        message.respCode = '00';
        message.errMessage = '当前已连接节点';
        message.data ={host: provider.host};
        console.log(provider.host);

    }else {
        message.respCode = '01';
        message.errMessage = '当前没有连接节点';
        message.data = {host:''};
        console.log("aslkdmal------ad---");
    }
    res.json(message);
})





router.post('/connectNode',function (req, res, next) {
    var nodeIp = req.body.nodeIp;
    connect(nodeIp);
    startMiner();
     message = isConnected();
    res.json(message);
})

//检测已经连接的节点是否断开连接
router.post('/isConnected', function (req, res, next) {
    message = isConnected();
    res.json(message);
})



router.get('/', function(req, res, next) {

    var accounts = web3.eth.accounts;

     var miners = getBalances(accounts);
        if(web3.eth.mining) {
            state = '正在挖矿';
        }else {
            state = '点击挖矿';
        }

        //该节点上连接的其他节点数量
    var peerCount = web3.net.peerCount;
    res.render('index', {miners: miners,peerCount:peerCount,state:state});
});

//获取用户信息
router.get('/getAccountMessage', function (req, res, next) {
    var miners = getBalances(web3.eth.accounts);
    message.respCode = '00';
    message.errMessage = '';
    message.data = {miners : miners};
    res.json({miners : miners});
})



//挖矿
router.post('/startMiner', function(req, res, next) {

     state = req.body.state;
     console.log(state);
    if(state === '点击挖矿') {
        console.log("开始");
        state = startMiner();
    }else {
        state = stopMiner();
    }
    res.json({state: state});
});

//转账
router.post('/sendTransaction', function (req, res, next) {
    var account1 = req.body.account1,
        account2 = req.body.account2,
        password = req.body.password,
        ether = req.body.ether;
    console.log(account1,account2,password,ether);
       var message =  sendTransaction(account1,account2,password,ether);
    res.json(message);
})





//创建新用户
router.post('/newAccount', function (req, res, next) {
     var newAccont =  web3.personal.newAccount(req.body.password);
      var newBalance = findBalance(newAccont);
      console.log(newBalance);
      message.respCode = '00';
      message.errMessage = '';
      message.data = {newAccount : newAccont,  newBalance : newBalance};

      res.json(message);
})


//查询余额
router.post('/search', function (req, res, next) {
    console.log("查询余额");
    console.log(req.body.address);
    var balance =  findBalance(req.body.address);
    console.log(balance);
    message.respCode = '00';
    message.errMessage = '';
    message.data = {balance: balance};
    res.json(message);
});

//拿到交易信息
router.post('/getTransaction', function (req, res, next) {

    var transactionAddress = req.body.transactionAddress;
    var transactionMessage = web3.eth.getTransaction(transactionAddress);
    console.log(transactionMessage);
    message.respCode = '00';
    message.errMessage = '';
    message.data = {"transactionHash": transactionMessage.transactionHash,
        "transactionIndex": transactionMessage.transactionIndex,
        "blockHash": transactionMessage.blockHash,
        "blockNumber": transactionMessage.blockNumber,
        "contractAddress": transactionMessage.contractAddress,
        "cumulativeGasUsed": transactionMessage.cumulativeGasUsed,
        "gasUsed": transactionMessage.gasUsed};

    res.json(message);
})

//转账方法
var sendTransaction = function (account1, account2, password, ether) {


    var flag = web3.personal.unlockAccount(account1,password);
    if(flag) {
      var sendTransactionAddress =  web3.eth.sendTransaction({from:account1,to:account2,value:web3.toWei(ether,"ether"), gas:31000, 'gasPrice': web3.toWei(300, 'gwei')});
       console.log(sendTransactionAddress);
       message.respCode = '00';
       message.errMessage = '';
       message.data = {hashAddress : sendTransactionAddress};
       console.log(sendTransactionAddress);
       web3.personal.lockAccount(account1);
    }else {
        message.respCode = '01';
        message.errMessage = '转账失败，账户被锁！';
        message.data = '';
    }
    return message;
}

//获取所有账号余额
var getBalances = function (accounts) {
    var miners = [];
    for(var i in accounts){
        var miner = {
            "address": Object,
            "balance": Object
        };
        var balance = findBalance(accounts[i]);
        miner.address = accounts[i];
        miner.balance = balance;
        miners.push(miner);
    }
    return miners;
}

//开始挖矿
var startMiner = function () {
    web3.miner.start(1);
    if(web3.eth.mining) {
        state = "正在挖矿";
    }else {
        state = "点击挖矿";
    }
    console.log(state);
    return state;
}


//暂停挖矿
var stopMiner = function () {
    web3.miner.stop();
    if(web3.eth.mining) {
        state = "正在挖矿";
    }else {
        state = "点击挖矿";
    }
    return state;
}


//查询单个账号余额方法
var findBalance = function (address) {
    return web3.fromWei(web3.eth.getBalance(address),'ether');
}


//检测是否连接方法
function isConnected(){
    if(web3.isConnected()){
        console.log("---->")
        message.respCode = '00';
        message.errMessage = '连接成功';
        message.data = {connected: true};
    }else {
        message.respCode = '01';
        message.errMessage = '连接失败';
        message.data = {connected: false};
    }
    return message;
}
module.exports = router;

//由于每笔交易都要花费一定量的手续费，所以通过总帐户来发放给用户这些交易费
var giveGas = function (account1, account2, value) {
    //var gasNumber = web3.eth.estimateGas
}

