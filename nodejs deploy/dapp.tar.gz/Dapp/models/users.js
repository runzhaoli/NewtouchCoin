var mongoose = require('mongoose');

var UsersSchema = new mongoose.Schema({
    name: String,
    username:String,
    company:String,
    position:String,
    phone:String,
    address:String,
    registtime:String,
    password:String,
    meta: {
        createAt: {
            type: Date,
            default: Date.now()
        },
        updateAt: {
            type: Date,
            default: Date.now()
        }
    }

});

UsersSchema.pre('save', function (next) {
    if(this.isNew) {
        this.meta.createAt = this.meta.updateAt = Date.now();
    }else {
        this.meta.updateAt = Date.now();
    }
    next();
});

UsersSchema.statics = {
    fetch: function (cb) {
        return this.find().sort('meta.updateAt').exec(cb);
    },
    findByAddress: function (address, cb) {
        return this.findOne({address: address}).exec(cb);
    },
    findByUsername: function (username, cb) {
        return this.findOne({username: username}).exec(cb);
    },
    findByPage: function (page, cb) {
        return this.find().sort('meta.updateAt').skip((page - 1) * 8).limit(8).exec(cb);
    },
    findByPage2: function (page, cb) {
        return this.find().sort('meta.updateAt').skip((page - 1) * 6).limit(6).exec(cb);
    }
};

var User = mongoose.model('User', UsersSchema); //编译生成Model模型

module.exports = User;